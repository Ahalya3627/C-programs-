#include <stdio.h>
int main()
{
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int a[n];
    printf("Enter the elements: ");
    for (int i = 0; i < n; i++) 
    {
        scanf("%d", &a[i]);
    }

    int l = a[0];  
    int sl = -1;   

    for (int i = 1; i < n; i++)
    {
        if (a[i] > l) 
        {
            sl = l; 
            l = a[i];
        }
        else if (a[i] > sl && a[i] != l)
        {
            sl = a[i];
        }
    }

    if (sl == -1)
    {
        printf("There is no second largest element in the array.\n");
    } else
    {
        printf("The second largest element is: %d\n", sl);
    }

    return 0;
}
