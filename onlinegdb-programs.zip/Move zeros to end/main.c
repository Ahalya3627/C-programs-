#include <stdio.h>

int main()
{
    int n;
    scanf("%d", &n);
    int a[n];

    for (int i = 0; i < n; i++) 
    {
        scanf("%d", &a[i]);
    }

    int c = 0; 
    for (int i = 0; i < n; i++) 
    {
        if (a[i] != 0)
        {
            int t = a[i];
            a[i] = a[c];
            a[c] = t;
            c++;
        }
    }

    for (int i = 0; i < n; i++)
    {
        printf("%d ", a[i]);
    }

    return 0;
}
