#include <stdio.h>

int main()
{
    int n, i;
    scanf("%d", &n);
    int a[n], pos[n], neg[n], zero[n];
    int p = 0, q = 0, z = 0;
    
    for (i = 0; i < n; i++) 
    {
        scanf("%d", &a[i]);
        if (a[i] > 0) pos[p++] = a[i];
        else if (a[i] < 0) neg[q++] = a[i];
        else zero[z++] = a[i];
    }
    
    i = 0;
    int j = 0;
    while (i < p && j < q) 
    
    while (i < p) 
    {
        printf("%d ", pos[i]);
        i++;
    }
    while (j < q) 
    {
        printf("%d ", neg[j]);
        j++;
    }
    for (i = 0; i < z; i++)
    {
        printf("0 ");
    }
    
    return 0;
}