#include <stdio.h>

int main() 
{
    int n, a[100], freq[100] = {0}, max = 0, res = 0;
    printf("Enter the number of elements:");
    scanf("%d", &n); 
    printf("Enter the elements:");
    if(n==0)
        {
            printf("Invalid size. Please enter a number between 1 and 100.");
            return 0;
        }
    for (int i = 0; i < n; i++) 
    {
        scanf("%d", &a[i]);  
        freq[a[i]]++;  
        if (freq[a[i]] > max) 
        {
            max = freq[a[i]];  
            res = a[i];  
        }
        
    }
    printf("Most frequent element:%d\n", res);  
    return 0;
}
