#include <stdio.h>

int main()
{
    int a[100],n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int k;
    scanf("%d",&k);
    for(int i=0;i<k;i++)
    {
        int temp=a[0];
        for(int j=0;j<n-i;j++)
        {
            a[j]=a[j+1];
        }
        a[n-1]=temp;
    }
    for(int i=0;i<n;i++)
    {
        printf("%d",a[i]);
    }
    return 0;
}
