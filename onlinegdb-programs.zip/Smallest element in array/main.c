#include <stdio.h>

int main() 
{
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int a[n];
    printf("Enter the elements: ");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    int s=a[0];

    for (int i = 1; i < n; i++) 
    {
        if (a[i] < s) 
        {
            s = a[i]; 
        }
    }
    printf("Smallest element in the gn array is :%d",s);
            
    return 0;
}

