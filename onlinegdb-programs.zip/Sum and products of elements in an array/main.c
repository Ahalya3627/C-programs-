#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    int s=0,p=1;
    for(int i=0;i<n;i++)
    {
        s+=a[i];
        p*=a[i];
    }
    printf("Sum:%d",s);
    printf("\nProduct:%d",p);
    return 0;
}
