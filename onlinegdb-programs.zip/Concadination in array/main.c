#include<stdio.h>
int main()
{
int n,i,num;
scanf("%d",&n);
int arr[n];
int d=n*2;
int ans[d];
for(i=0;i<n;i++)
{
    scanf("%d",&arr[i]);
}
for(i=0;i<n;i++)
{
    ans[2*i]=arr[i];
    ans[2*i+1]=arr[i];
    
}
for(i=0;i<d;i++)
{
    printf("%d",ans[i]);
    
}
 return 0;  
}
