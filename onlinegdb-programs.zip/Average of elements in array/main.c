#include <stdio.h>
int main()
{
   int n;
   printf("Enter the number of elements:");
   scanf("%d",&n);
   int a[n];
   for(int i=0;i<n;i++)
   {
       scanf("%d",&a[i]);
   }
   int s=0;
   for(int i=0;i<n;i++)
   {
       s+=a[i];
   }
   int avg=s/n;
   printf("The average of the elements in the array is:%d",avg);
    return 0;
} 
