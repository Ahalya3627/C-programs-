#include <stdio.h>

int main() 
{
    int n;
    printf("number of elements: ");
    scanf("%d", &n);

    int a[n], v[n];

    printf("Enter the elements:\n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
        v[i] = 0;
    }

    printf("Number occurrences:\n");
    for (int i = 0; i < n; i++) 
    {
        if (v[i] == 1)
            continue;

        int c= 1;
        for (int j = i + 1; j < n; j++)
        {
            if (a[i] == a[j]) 
            {
                c++;
                v[j] = 1;
            }
        }
        printf("%d occurs %d times\n", a[i], c);
    }

    return 0;
}
