#include <stdio.h>
#include <string.h>

int main()
{
    char s[100];
    scanf("%s",s);
    int l=strlen(s);
    for(int i=0;i<l/2;i++)
    {
        if(s[i]!=s[l-1-i])
        {
            printf("Not a Palindrome");
            return 0;
        }
    }
    printf("Palindrome");
    return 0;
}
